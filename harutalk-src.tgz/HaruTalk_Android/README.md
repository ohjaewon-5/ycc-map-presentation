# HaruTalk Android 2.0

This is a clean Android rebuild. It does not reuse the hand-edited APK/DEX files from v1.x.

## Core behavior
- Native Android Activity, no WebView.
- Korean and Japanese microphone buttons via Android SpeechRecognizer.
- Falls back to the system RecognizerIntent if in-app recognition cannot start.
- Korean ↔ Japanese on-device translation via Google ML Kit (`com.google.mlkit:translate:17.0.3`).
- First translation can download language models (~30 MB per language model according to ML Kit documentation).
- Android TextToSpeech playback for translated text.
- No API key and no MyMemory/Google Translate web scraping.

## Build
Requires Android SDK 35, JDK 17, and Gradle 8.9.

    gradle testDebugUnitTest lintDebug assembleDebug

The installable debug APK is produced at:
`app/build/outputs/apk/debug/app-debug.apk`

## Validation plan
The included GitHub Actions workflow compiles the app, runs unit tests and Android lint, then boots an API 35 Google APIs emulator, installs the APK, launches `MainActivity`, verifies the process is alive, and fails if logcat contains a fatal exception for the app process.

Physical microphone recognition still requires validation on a real Android phone because CI emulators do not provide a representative phone microphone/recognition-service environment.
