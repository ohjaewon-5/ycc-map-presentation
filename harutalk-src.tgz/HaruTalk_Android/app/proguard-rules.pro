# Intentionally minimal. ML Kit ships consumer rules for its own classes.
