package com.harutalk.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class SanityTest {
    @Test
    public void directionLabelsAreDistinct() {
        assertNotEquals("한국어 → 日本語", "日本語 → 한국어");
    }
}
