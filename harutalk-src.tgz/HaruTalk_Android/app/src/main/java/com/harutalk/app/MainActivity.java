package com.harutalk.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements RecognitionListener {
    private static final int REQ_MIC = 41;
    private static final int REQ_FALLBACK_KO = 51;
    private static final int REQ_FALLBACK_JA = 52;

    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private EditText input;
    private TextView status;
    private Button micKo;
    private Button micJa;
    private Button sendKo;
    private Button sendJa;

    private SpeechRecognizer speechRecognizer;
    private String pendingSpeechLanguage;
    private String currentSpeechLanguage;
    private boolean listening;

    private Translator koToJa;
    private Translator jaToKo;
    private TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        boolean translationReady = initTranslationSafely();
        initTtsSafely();
        initSpeechRecognizer();
        status.setText(translationReady
                ? "준비됨 · 처음 번역할 때 언어 모델을 다운로드할 수 있습니다."
                : "앱은 실행됐지만 번역 엔진 초기화에 실패했습니다. 음성 입력과 텍스트 입력은 확인할 수 있습니다.");
    }

    private void buildUi() {
        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(18), pad, pad);
        root.setBackgroundColor(Color.rgb(247, 248, 252));

        TextView title = new TextView(this);
        title.setText("하루톡 · 한국어 ↔ 日本語");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(30, 40, 65));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, lpMatchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("말하면 인식하고, 기기에서 번역해 대화창에 표시합니다.");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.rgb(105, 116, 139));
        LinearLayout.LayoutParams subLp = lpMatchWrap();
        subLp.topMargin = dp(4);
        root.addView(subtitle, subLp);

        status = new TextView(this);
        status.setTextSize(12);
        status.setTextColor(Color.rgb(56, 108, 82));
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status, lpMatchWrap());

        chatScroll = new ScrollView(this);
        chatScroll.setFillViewport(true);
        chatContainer = new LinearLayout(this);
        chatContainer.setOrientation(LinearLayout.VERTICAL);
        chatContainer.setPadding(0, dp(8), 0, dp(8));
        chatScroll.addView(chatContainer, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams chatLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(chatScroll, chatLp);

        input = new EditText(this);
        input.setHint("문장을 입력하거나 아래 마이크를 누르세요");
        input.setTextSize(16);
        input.setTextColor(Color.rgb(32, 44, 67));
        input.setHintTextColor(Color.rgb(145, 155, 173));
        input.setBackgroundColor(Color.WHITE);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setMinLines(2);
        input.setMaxLines(4);
        LinearLayout.LayoutParams inputLp = lpMatchWrap();
        inputLp.topMargin = dp(8);
        root.addView(input, inputLp);

        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setOrientation(LinearLayout.HORIZONTAL);
        sendRow.setPadding(0, dp(8), 0, 0);
        sendKo = makeButton("한국어 → 日本語", 0xFF4455D9, Color.WHITE);
        sendJa = makeButton("日本語 → 한국어", 0xFF287957, Color.WHITE);
        sendRow.addView(sendKo, weightedLp());
        LinearLayout.LayoutParams jaLp = weightedLp();
        jaLp.leftMargin = dp(8);
        sendRow.addView(sendJa, jaLp);
        root.addView(sendRow, lpMatchWrap());

        LinearLayout micRow = new LinearLayout(this);
        micRow.setOrientation(LinearLayout.HORIZONTAL);
        micRow.setPadding(0, dp(8), 0, 0);
        micKo = makeButton("🎤 한국어로 말하기", 0xFFEEF0FF, 0xFF4455D9);
        micJa = makeButton("🎤 日本語で話す", 0xFFEAF7F1, 0xFF287957);
        micRow.addView(micKo, weightedLp());
        LinearLayout.LayoutParams micJaLp = weightedLp();
        micJaLp.leftMargin = dp(8);
        micRow.addView(micJa, micJaLp);
        root.addView(micRow, lpMatchWrap());

        sendKo.setOnClickListener(v -> translateInput(true));
        sendJa.setOnClickListener(v -> translateInput(false));
        micKo.setOnClickListener(v -> beginSpeech("ko-KR"));
        micJa.setOnClickListener(v -> beginSpeech("ja-JP"));

        setContentView(root);
    }

    private boolean initTranslationSafely() {
        try {
            TranslatorOptions koJaOptions = new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.KOREAN)
                    .setTargetLanguage(TranslateLanguage.JAPANESE)
                    .build();
            TranslatorOptions jaKoOptions = new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.JAPANESE)
                    .setTargetLanguage(TranslateLanguage.KOREAN)
                    .build();
            koToJa = Translation.getClient(koJaOptions);
            jaToKo = Translation.getClient(jaKoOptions);
            return true;
        } catch (Throwable t) {
            koToJa = null;
            jaToKo = null;
            return false;
        }
    }

    private void initTtsSafely() {
        try {
            tts = new TextToSpeech(this, result -> {
                if (result != TextToSpeech.SUCCESS) {
                    runOnUiThread(() -> status.setText("읽어주기 초기화 실패 · 번역 기능은 사용할 수 있습니다."));
                }
            });
        } catch (Throwable t) {
            tts = null;
        }
    }

    private void initSpeechRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(this);
            } else {
                status.setText("기본 음성인식 서비스를 찾지 못했습니다. 마이크를 누르면 시스템 음성입력을 시도합니다.");
            }
        } catch (Throwable t) {
            speechRecognizer = null;
            status.setText("음성인식 초기화 실패 · 시스템 음성입력으로 대체합니다.");
        }
    }

    private void beginSpeech(String languageTag) {
        if (listening) {
            stopListening();
            return;
        }
        pendingSpeechLanguage = languageTag;
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startSpeechNow(languageTag);
    }

    private void startSpeechNow(String languageTag) {
        currentSpeechLanguage = languageTag;
        input.setText("");
        if (speechRecognizer == null) {
            launchFallbackRecognizer(languageTag);
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        try {
            speechRecognizer.startListening(intent);
            listening = true;
            setListeningUi(true, languageTag);
            status.setText(languageTag.startsWith("ko") ? "한국어를 듣는 중입니다…" : "日本語を聞いています…");
        } catch (Throwable t) {
            listening = false;
            setListeningUi(false, languageTag);
            status.setText("앱 내 음성인식을 시작하지 못해 시스템 음성입력으로 전환합니다.");
            launchFallbackRecognizer(languageTag);
        }
    }

    private void launchFallbackRecognizer(String languageTag) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, languageTag.startsWith("ko") ? "한국어로 말씀하세요" : "日本語で話してください");
        int code = languageTag.startsWith("ko") ? REQ_FALLBACK_KO : REQ_FALLBACK_JA;
        try {
            startActivityForResult(intent, code);
        } catch (ActivityNotFoundException e) {
            status.setText("이 휴대폰에서 사용할 수 있는 음성인식 앱을 찾지 못했습니다.");
            Toast.makeText(this, "Google 앱 또는 삼성 음성입력 설정을 확인해 주세요.", Toast.LENGTH_LONG).show();
        }
    }

    private void translateInput(boolean koreanToJapanese) {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "먼저 문장을 입력하거나 말해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        translateAndAppend(text, koreanToJapanese);
    }

    private void translateAndAppend(String text, boolean koreanToJapanese) {
        Translator translator = koreanToJapanese ? koToJa : jaToKo;
        if (translator == null) {
            status.setText("번역 엔진을 사용할 수 없습니다. 앱을 완전히 종료한 뒤 다시 실행해 주세요.");
            return;
        }
        String direction = koreanToJapanese ? "한국어 → 日本語" : "日本語 → 한국어";
        status.setText("번역 모델 확인 중… 처음 사용 시 약 30MB 모델을 받을 수 있습니다.");
        setBusy(true);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(unused -> {
                    status.setText("번역 중…");
                    translator.translate(text)
                            .addOnSuccessListener(translated -> {
                                setBusy(false);
                                status.setText("번역 완료");
                                addMessage(direction, text, translated, koreanToJapanese ? Locale.JAPAN : Locale.KOREA);
                                input.setText("");
                            })
                            .addOnFailureListener(e -> {
                                setBusy(false);
                                status.setText("번역 실패: " + readableError(e));
                            });
                })
                .addOnFailureListener(e -> {
                    setBusy(false);
                    status.setText("번역 모델 준비 실패: " + readableError(e));
                });
    }

    private void addMessage(String direction, String original, String translated, Locale ttsLocale) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));
        card.setBackgroundColor(Color.WHITE);

        TextView meta = new TextView(this);
        meta.setText(direction);
        meta.setTextSize(11);
        meta.setTextColor(Color.rgb(105, 116, 139));
        card.addView(meta, lpMatchWrap());

        TextView originalView = new TextView(this);
        originalView.setText(original);
        originalView.setTextSize(14);
        originalView.setTextColor(Color.rgb(105, 116, 139));
        originalView.setPadding(0, dp(6), 0, 0);
        card.addView(originalView, lpMatchWrap());

        TextView translatedView = new TextView(this);
        translatedView.setText(translated);
        translatedView.setTextSize(21);
        translatedView.setTextColor(Color.rgb(30, 40, 65));
        translatedView.setPadding(0, dp(4), 0, dp(4));
        card.addView(translatedView, lpMatchWrap());

        Button speak = makeButton("🔊 번역문 듣기", 0xFFF0F2F7, 0xFF35415A);
        speak.setOnClickListener(v -> speakText(translated, ttsLocale));
        LinearLayout.LayoutParams speakLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        speakLp.topMargin = dp(4);
        card.addView(speak, speakLp);

        LinearLayout.LayoutParams cardLp = lpMatchWrap();
        cardLp.topMargin = dp(8);
        chatContainer.addView(card, cardLp);
        chatScroll.post(() -> chatScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void speakText(String text, Locale locale) {
        if (tts == null) return;
        int available = tts.setLanguage(locale);
        if (available == TextToSpeech.LANG_MISSING_DATA || available == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "해당 언어 음성이 설치되어 있지 않습니다.", Toast.LENGTH_LONG).show();
            return;
        }
        tts.setSpeechRate(0.88f);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "harutalk-utterance");
    }

    private void setBusy(boolean busy) {
        sendKo.setEnabled(!busy);
        sendJa.setEnabled(!busy);
        micKo.setEnabled(!busy);
        micJa.setEnabled(!busy);
    }

    private void setListeningUi(boolean active, String languageTag) {
        micKo.setText(active && languageTag.startsWith("ko") ? "■ 한국어 듣기 중" : "🎤 한국어로 말하기");
        micJa.setText(active && languageTag.startsWith("ja") ? "■ 日本語 認識中" : "🎤 日本語で話す");
    }

    private void stopListening() {
        try {
            if (speechRecognizer != null) speechRecognizer.stopListening();
        } catch (Throwable ignored) { }
        listening = false;
        setListeningUi(false, currentSpeechLanguage == null ? "ko-KR" : currentSpeechLanguage);
    }

    private String readableError(Exception e) {
        String msg = e.getMessage();
        return (msg == null || msg.trim().isEmpty()) ? e.getClass().getSimpleName() : msg;
    }

    private String speechErrorText(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "마이크 입력 오류";
            case SpeechRecognizer.ERROR_CLIENT: return "음성인식 요청 오류";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "마이크 권한 없음";
            case SpeechRecognizer.ERROR_NETWORK: return "음성인식 네트워크 오류";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "음성인식 연결 시간 초과";
            case SpeechRecognizer.ERROR_NO_MATCH: return "말을 인식하지 못했습니다";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "음성인식기가 사용 중입니다";
            case SpeechRecognizer.ERROR_SERVER: return "음성인식 서버 오류";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "말소리가 감지되지 않았습니다";
            default: return "음성인식 오류 " + error;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSpeechNow(pendingSpeechLanguage == null ? "ko-KR" : pendingSpeechLanguage);
            } else {
                status.setText("마이크 권한이 필요합니다. 설정 → 앱 → 하루톡 → 권한에서 마이크를 허용해 주세요.");
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode == REQ_FALLBACK_KO || requestCode == REQ_FALLBACK_JA) && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String text = results.get(0);
                input.setText(text);
                translateAndAppend(text, requestCode == REQ_FALLBACK_KO);
            }
        }
    }

    @Override public void onReadyForSpeech(Bundle params) { status.setText("말씀하세요…"); }
    @Override public void onBeginningOfSpeech() { status.setText("목소리 감지됨 · 인식 중…"); }
    @Override public void onRmsChanged(float rmsdB) { }
    @Override public void onBufferReceived(byte[] buffer) { }
    @Override public void onEndOfSpeech() { status.setText("인식 결과 확인 중…"); }

    @Override
    public void onError(int error) {
        listening = false;
        setListeningUi(false, currentSpeechLanguage == null ? "ko-KR" : currentSpeechLanguage);
        status.setText(speechErrorText(error));
        if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_SERVER) {
            launchFallbackRecognizer(currentSpeechLanguage == null ? "ko-KR" : currentSpeechLanguage);
        }
    }

    @Override
    public void onResults(Bundle results) {
        listening = false;
        setListeningUi(false, currentSpeechLanguage == null ? "ko-KR" : currentSpeechLanguage);
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) {
            status.setText("인식된 문장이 없습니다.");
            return;
        }
        String text = matches.get(0);
        input.setText(text);
        boolean ko = currentSpeechLanguage == null || currentSpeechLanguage.startsWith("ko");
        translateAndAppend(text, ko);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) input.setText(matches.get(0));
    }

    @Override public void onEvent(int eventType, Bundle params) { }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
        } catch (Throwable ignored) { }
        if (koToJa != null) koToJa.close();
        if (jaToKo != null) jaToKo.close();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

    private Button makeButton(String text, int background, int foreground) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(foreground);
        b.setBackgroundColor(background);
        b.setAllCaps(false);
        b.setMinHeight(dp(50));
        return b;
    }

    private LinearLayout.LayoutParams weightedLp() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams lpMatchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
